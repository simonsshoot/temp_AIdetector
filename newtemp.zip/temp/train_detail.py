import sys
sys.path.append('./')
import random
random.seed(42)
import argparse
from tqdm import tqdm
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "2"
import torch.optim as optim
import yaml
import torch
from torch.utils.data import DataLoader
from torch.utils.data.dataloader import default_collate 
from lightning.fabric.strategies import DDPStrategy
from transformers import AutoTokenizer
from lightning import Fabric
from dataset import MyDataset,MultiDataset
from models import SimCLR_Classifier_SCL,SimCLR_Classifier
from torch.utils.tensorboard import SummaryWriter


'''
指标：

二分类：准确率、F1、AUC-ROC。

伪装级别分类：按类别精确率、召回率、混淆矩阵。

消融实验：验证对比学习和层次化特征的有效性。

可视化：t-SNE降维对比学习的表示空间，观察不同类别的分离程度
'''

def collate_fn(batch):
    batch_dict = default_collate(batch) 
    articles = batch_dict[0] 
    articles = [str(article) if article is not None else '' for article in articles]
    label = batch_dict[1] 
    details = batch_dict[2] 
    classes=batch_dict[3]

    encoded_batch = tokenizer.batch_encode_plus(
        articles,
        return_tensors="pt",
        max_length=512,
        padding='max_length',
        truncation=True,
    )
    return {
        'input_ids': encoded_batch['input_ids'],
        'attention_mask': encoded_batch['attention_mask'],
        'label': label,
        'details': details,
        'classes':classes
    }


def train(opt):
    torch.set_float32_matmul_precision("medium")
    if opt.device_num>1:
        ddp_strategy = DDPStrategy(find_unused_parameters=True)
        fabric = Fabric(accelerator="cuda", precision="bf16-mixed", devices=opt.device_num,strategy=ddp_strategy)#
    else:
        fabric = Fabric(accelerator="cuda", precision="bf16-mixed", devices=opt.device_num)
    fabric.launch()

    human_train=MultiDataset("/home/yx/yx_search/search/DeTeCtive-new/mydata/human_pertubed/human_pertubed_train.jsonl",need_details=True)
    human_eval=MultiDataset("/home/yx/yx_search/search/DeTeCtive-new/mydata/human_pertubed/human_pertubed_eval.jsonl",need_details=True)
    machine_train=MultiDataset("/home/yx/yx_search/search/DeTeCtive-new/mydata/gpt_pertubed/gpt_pertubed_train.jsonl",need_details=True)
    machine_eval=MultiDataset("/home/yx/yx_search/search/DeTeCtive-new/mydata/gpt_pertubed/gpt_pertubed_eval.jsonl",need_details=True)
    train_dataset=human_train+machine_train
    eval_dataset=human_eval+machine_eval
    opt.classifier_dim=2

    train_dataloder = DataLoader(train_dataset, batch_size=opt.per_gpu_batch_size,\
                                     num_workers=opt.num_workers, pin_memory=True,shuffle=True,drop_last=True,collate_fn=collate_fn)
    # for batch in train_dataloder:
    #     print("Input:", batch['input_ids'][0])
    #     print("Label:", batch['label'][0])
    #     print("classes:",batch['classes'][0])
    #     break
    val_dataloder = DataLoader(eval_dataset, batch_size=opt.per_gpu_eval_batch_size,\
                            num_workers=opt.num_workers, pin_memory=True,shuffle=True,drop_last=False,collate_fn=collate_fn)
    
    model=SimCLR_Classifier(opt,fabric)
    train_dataloder,val_dataloder=fabric.setup_dataloaders(train_dataloder,val_dataloder)

    if fabric.global_rank == 0 :
        for num in range(10000):
            if os.path.exists(os.path.join(opt.savedir,'{}_v{}'.format(opt.name,num)))==False:
                opt.savedir=os.path.join(opt.savedir,'{}_v{}'.format(opt.name,num))
                os.makedirs(opt.savedir)
                break
        if os.path.exists(os.path.join(opt.savedir,'runs_detail'))==False:
            os.makedirs(os.path.join(opt.savedir,'runs_detail'))
        writer = SummaryWriter(os.path.join(opt.savedir,'runs_detail'))
        #save opt to yaml
        opt_dict = vars(opt)
        with open(os.path.join(opt.savedir,'config.yaml'), 'w') as file:
            yaml.dump(opt_dict, file, sort_keys=False)


    num_batches_per_epoch = len(train_dataloder)
    warmup_steps=opt.warmup_steps
    lr = opt.lr
    total_steps = opt.total_epoch * num_batches_per_epoch- warmup_steps
    optimizer = optim.AdamW(filter(lambda p : p.requires_grad, model.parameters()), lr=opt.lr, betas=(opt.beta1, opt.beta2), eps=opt.eps, weight_decay=opt.weight_decay)

    schedule = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, total_steps, eta_min=lr/10)
    model, optimizer = fabric.setup(model, optimizer)
    max_avg_rec=0
    for epoch in range(opt.total_epoch):
        model.train()
        avg_loss=0
        pbar = enumerate(train_dataloder)
        pbar = tqdm(pbar, total=len(train_dataloder))
        print(('\n' + '%9s' *(6)) % ('Epoch', 'GPU_mem', 'Cur_loss', 'avg_loss','lr','      train_acc'))
        right_num,tot_num=0,0
        for i,batch in pbar:
            optimizer.zero_grad()
            current_step=epoch*num_batches_per_epoch+i
            if current_step < warmup_steps:
                current_lr = lr * current_step / warmup_steps
                for param_group in optimizer.param_groups:
                    param_group['lr'] = current_lr
            current_lr = optimizer.param_groups[0]['lr']


            labels=batch['label']
            classes=batch['classes']
            loss,out,k_index1,k_label = model(batch,labels,classes)
            _,preds=torch.max(out,dim=1)
            print("preds:\n")
            print(preds)
            print("labels:\n")
            print(labels)
            correct = (preds==labels).sum().item()
            right_num += correct
            tot_num += labels.shape[0]
            accuracy = correct / labels.shape[0]
            avg_loss=(avg_loss*i+loss.item())/(i+1)
            fabric.backward(loss)
            optimizer.step()
            if current_step >= warmup_steps:
                schedule.step()

            mem = f'{torch.cuda.memory_reserved() / 1E9 if torch.cuda.is_available() else 0:.3g}G'
            if fabric.global_rank == 0:
                pbar.set_description(
                    ('%10s' * 2 + '%10.4g' * 4) %
                    (f'{epoch + 1}/{opt.total_epoch}', mem, loss.item(),avg_loss, current_lr,accuracy)
                )        
                if current_step%10==0:
                    writer.add_scalar('lr', current_lr, current_step)
                    writer.add_scalar('loss', loss.item(), current_step)
                    writer.add_scalar('avg_loss', avg_loss, current_step)
        
        with torch.no_grad():
            test_loss=0
            model.eval()
            pbar=enumerate(val_dataloder)
            if fabric.global_rank == 0 :
                pbar = tqdm(pbar, total=len(val_dataloder))
                print(('\n' + '%11s' *(5)) % ('Epoch', 'GPU_mem', 'Cur_acc', 'avg_acc','loss'))
            
            right_num, tot_num= 0,0
            avg_acc=0.0
            for i, batch in pbar:
                # encoded_batch, label = batch
                # encoded_batch = {k: v.cuda() for k, v in encoded_batch.items()}
                # label = label.cuda()
                labels=batch['label']
                classes=batch['classes']
                loss,out,k_index1,k_label = model(batch,labels,classes)

                _, predicted = torch.max(out, dim=1)
                print("preds:\n")
                print(predicted)
                print("labels:\n")
                print(labels)
               
                correct = (predicted ==labels).sum().item()
                right_num += correct
                tot_num += labels.shape[0]
                accuracy = correct / labels.shape[0]
                # print(f"label_size:{label.size(0)}\n")
                # print(f"eval_acc:{accuracy:.4f}\n")
                avg_acc = (avg_acc * i + accuracy) / (i + 1)

                if fabric.global_rank == 0:
                    pbar.set_description(
                        ('%11s' * 2 + '%11.4g' * 2) %
                        (f'{epoch + 1}/{opt.total_epoch}', mem, accuracy, avg_acc)
                    )
            if fabric.global_rank == 0:
                writer.add_scalar('eval_loss', test_loss, epoch)
                writer.add_scalar('eval_acc', avg_acc, epoch)

            if avg_acc > max_avg_rec:
                max_avg_rec = avg_acc
                torch.save(model.get_encoder().state_dict(), os.path.join(opt.savedir,'model_best.pth'))
                torch.save(model.state_dict(), os.path.join(opt.savedir,'model_classifier_best.pth'))
                print('Save model to {}'.format(os.path.join(opt.savedir,'model_best.pth'.format(epoch))), flush=True)
                print(f"New best model saved with accuracy: {avg_acc:.4f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--device_num', type=int, default=1, help="GPU number to use")
    parser.add_argument('--projection_size', type=int, default=768, help="Pretrained model output dim")
    parser.add_argument("--temperature", type=float, default=0.07, help="contrastive loss temperature")
    parser.add_argument('--num_workers', type=int, default=8, help="num_workersd for dataloader")
    parser.add_argument("--per_gpu_batch_size", default=32, type=int, help="Batch size per GPU for training.")
    parser.add_argument(
        "--per_gpu_eval_batch_size", default=32, type=int, help="Batch size per GPU for evaluation."
    )
    parser.add_argument('--human_dataset_path', type=str, default='/home/yx/yx_search/search/DeTeCtive-new/mydata/human', help="train,valid,test,test_ood")
    parser.add_argument('--gpt_dataset_path', type=str, default='/home/yx/yx_search/search/DeTeCtive-new/mydata/gptnone', help="train,valid,test,test_ood")

    '''abcd代表四个分类器的权重！损失函数为加权损失和'''
    parser.add_argument('--a', type=float, default=1)
    parser.add_argument('--b', type=float, default=1) 
    parser.add_argument('--c', type=float, default=1)
    parser.add_argument('--d', type=float, default=1,help="单词句子段落其他")
    parser.add_argument('--e', type=float, default=1,help="classifier loss weight")
    parser.add_argument('--esp',type=float,default=1e-6,help="epsilon for label smoothing")

    parser.add_argument('--simple_classifier',type=bool,default=True,help="是否使用简单分类器")

    parser.add_argument("--lr", type=float, default=4e-5, help="learning rate")
    parser.add_argument("--weight_decay", type=float, default=0.0001, help="weight decay")
    parser.add_argument("--total_epoch", type=int, default=10, help="Total number of training epochs")
    parser.add_argument("--warmup_steps", type=int, default=1000, help="Warmup steps")
    parser.add_argument("--resum", type=bool, default=False)
    parser.add_argument("--optim", type=str, default="adamw")
    parser.add_argument("--savedir", type=str, default="./runs_detail")
    parser.add_argument("--name", type=str, default="trival")
    parser.add_argument('--model_name', type=str, default='/data/Content Moderation/unsup-simcse-roberta-base')

    '''beta1控制一阶动量（梯度的指数移动平均），beta2控制二阶动量（梯度平方的指数移动平均）。默认值通常为(0.9, 0.999)'''
    parser.add_argument("--beta1", type=float, default=0.9, help="beta1")
    parser.add_argument("--beta2", type=float, default=0.98, help="beta2")
    parser.add_argument("--eps", type=float, default=1e-6, help="eps")
    opt=parser.parse_args()
    tokenizer = AutoTokenizer.from_pretrained(opt.model_name)
    train(opt)
