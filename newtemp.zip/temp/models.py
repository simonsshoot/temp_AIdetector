import torch
import torch.nn as nn
import torch.nn.functional as F
from text_embedding import TextEmbeddingModel

class ClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, in_dim, out_dim):
        super(ClassificationHead, self).__init__()
        self.dense1 = nn.Linear(in_dim, in_dim//4)
        self.dense2 = nn.Linear(in_dim//4, in_dim//16)
        self.out_proj = nn.Linear(in_dim//16, out_dim)
        nn.init.xavier_uniform_(self.dense1.weight)
        nn.init.xavier_uniform_(self.dense2.weight)
        nn.init.xavier_uniform_(self.out_proj.weight)
        nn.init.normal_(self.dense1.bias, std=1e-6)
        nn.init.normal_(self.dense2.bias, std=1e-6)
        nn.init.normal_(self.out_proj.bias, std=1e-6)

    def forward(self, features):
        x = features
        x = self.dense1(x)
        x = torch.tanh(x)
        x = self.dense2(x)
        x = torch.tanh(x)
        x = self.out_proj(x)
        return x
    

class SimCLR_Classifier_SCL(nn.Module):
    def __init__(self, opt,fabric):
        super(SimCLR_Classifier_SCL, self).__init__()
        
        self.temperature = opt.temperature
        self.opt=opt
        #自动检测并配置可用的硬件资源并优化加速
        self.fabric = fabric

        self.model = TextEmbeddingModel(opt.model_name)
        self.device=self.model.model.device
        if opt.resum:
            state_dict = torch.load(opt.pth_path, map_location=self.device)
            self.model.load_state_dict(state_dict)
        self.esp=torch.tensor(1e-6,device=self.device)

        self.classifier = ClassificationHead(opt.projection_size, opt.classifier_dim)

    def get_encoder(self):
        return self.model

    def forward(self, batch, labels):
        input_ids = batch['input_ids']
        attention_mask = batch['attention_mask']
        embeddings = self.model(input_ids, attention_mask)
        logits = self.classifier(embeddings)

        loss = F.cross_entropy(logits, labels)
        
        return loss, logits
    

class SimCLR_Classifier(nn.Module):
    def __init__(self, opt,fabric):
        super(SimCLR_Classifier, self).__init__()
        
        self.temperature = opt.temperature
        self.opt=opt
        self.fabric = fabric
        self.model = TextEmbeddingModel(opt.model_name)

        if opt.resum:
            state_dict = torch.load(opt.pth_path, map_location=self.model.model.device)
            self.model.load_state_dict(state_dict)

        self.classifier = ClassificationHead(opt.projection_size, opt.classifier_dim)

        self.device=self.model.model.device
        self.a=torch.tensor(opt.a,device=self.device)
        self.b=torch.tensor(opt.b,device=self.device)
        self.c=torch.tensor(opt.c,device=self.device)
        self.d=torch.tensor(opt.d,device=self.device)
        self.e=torch.tensor(opt.e,device=self.device)
        self.esp=torch.tensor(opt.esp,device=self.device)
        
    def get_encoder(self):  
        return self.model
    
    def _compute_logits(self, q,q_index1,q_label,k,k_index1,k_label):
        def cosine_sim(x, y):
            x_norm=F.normalize(x,dim=-1)
            y_norm=F.normalize(y,dim=-1)
            return x_norm@y_norm.t()
        '''
        q_index1 和 k_index1表示表示机器伪装文本的类别，
        label表示人类还是机器
        '''
        logits=cosine_sim(q,k)/self.temperature
        q_index1=q_index1.view(-1, 1)# N,1
        q_labels=q_label.view(-1, 1)# N,1
        # print(f'q_labels shape: {q_labels.shape}')

        k_index1=k_index1.view(1, -1)# 1,N+K
        k_labels=k_label.view(1, -1)# 1,N+K
        # print(f'k_index1 shape: {k_index1.shape}')
        is_human=(q_label==1).view(-1)
        is_machine=(q_label==0).view(-1)

        same_class=(q_index1==k_index1)
        same_label=(q_labels==k_labels)
        # print(f'same_class shape: {same_class.shape}')
        # print(f'logits shape: {logits.shape}')
        pos_logits_human=torch.sum(logits*same_label,dim=1)/torch.max(torch.sum(same_label,dim=1),self.esp)
        neg_logits_human=logits*torch.logical_not(same_label)

        logits_human=torch.cat((pos_logits_human.unsqueeze(1), neg_logits_human), dim=1)
        #仅保留人类生成的样本
        logits_human=logits_human[is_human]
        # print(f'logits_human shape: {logits_human.shape}')

        pos_logits_class=torch.sum(logits*same_class,dim=1)/torch.max(torch.sum(same_class,dim=1),self.esp)
        neg_logits_class=logits*torch.logical_not(same_class)
        logits_class=torch.cat((pos_logits_class.unsqueeze(1), neg_logits_class), dim=1)
        logits_class=logits_class[is_machine]
        # print(f'logits_class shape: {logits_class.shape}')
        # print(f'k_index1 shape: {k_index1.shape}')

        '''
        logits_label:所有机器的文本相似度应该高于人类生成的文本
        logits_class:对于同一伪装层次的样本，其相似度应该高于不同伪装层次的样本
        logits_human:对于人类撰写的样本，与其他人撰写的样本的相似度应高于与AI生成样本的相似度。
        '''
        pos_logits_machine=torch.sum(logits*torch.logical_not(same_label),dim=1)/torch.max(torch.sum(torch.logical_not(same_label),dim=1),self.esp)
        neg_logits_machine=logits*same_label
        logits_machine=torch.cat((pos_logits_machine.unsqueeze(1), neg_logits_machine), dim=1)
        logits_machine=logits_machine[is_machine]
        # print(f'logits_machine shape: {logits_machine.shape}')
        


        return logits_human,logits_class,logits_machine 

    
    def forward(self, batch, labels,classes):
        input_ids = batch['input_ids']
        attention_mask = batch['attention_mask']
        q=self.model(input_ids, attention_mask)
        k=q.clone().detach()
        # print(f'q shape: {q.shape}')
        # print(f'k shape: {k.shape}')
        k=self.fabric.all_gather(k).view(-1,k.size(1))
        # print(f'k gather shape: {k.shape}')
        k_label=self.fabric.all_gather(labels).view(-1)
        # print(f'k_label shape: {k_label.shape}')
        k_index1=self.fabric.all_gather(classes).view(-1)
        # print(f'k_index1 shape: {k_index1.shape}')
        logits_human,logits_class,logits_machine=self._compute_logits(q,labels,classes,k,k_index1,k_label)
        out=self.classifier(q)
        gt_human = torch.zeros(logits_human.size(0), dtype=torch.long,device=logits_human.device)
        if logits_human.numel()!=0:
            loss_human = F.cross_entropy(logits_human.to(torch.float64), gt_human)
        else:
            loss_human=torch.tensor(0,device=self.device)
        gt_class=torch.zeros(logits_class.size(0),dtype=torch.long,device=logits_class.device)
        gt_machine = torch.zeros(logits_machine.size(0), dtype=torch.long,device=logits_machine.device)
        loss_machine=F.cross_entropy(logits_machine,gt_machine)
        loss_classify=F.cross_entropy(out,labels)
        loss_class=F.cross_entropy(logits_class,gt_class)
        loss=self.a*loss_class+self.b*loss_machine+self.c*loss_human+self.d*loss_classify
        return loss,out,k_index1,k_label











  